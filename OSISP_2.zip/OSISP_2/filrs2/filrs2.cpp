﻿#include <iostream>
#include <vector>
#include <cmath>
#include <chrono>
#include <windows.h>
#include <cstdlib>

// Global number of threads (will be set in main)
size_t NUM_THREADS = 8;

// Total number of integers to process
const size_t NUM_INTS = 4 * 1024 * 1024;

// Structure to hold data for each thread in memory-mapped approach
struct ThreadDataMMap {
    int* start;               // Pointer to the start of data for this thread
    size_t length;            // Number of integers to process
    long double partialSum;   // Partial sum calculated by the thread
};

// Structure to hold data for each thread in traditional I/O approach
struct ThreadDataTraditional {
    HANDLE file;              // File handle for the thread
    LARGE_INTEGER startOffset; // Start position in the file (in bytes)
    size_t length;            // Number of integers to process
    long double partialSum;   // Partial sum calculated by the thread
};

// Function that each thread will run to process its chunk of data (for memory-mapped files)
DWORD WINAPI processChunkMMap(LPVOID param) {
    ThreadDataMMap* data = static_cast<ThreadDataMMap*>(param);

    // Process the data
    for (size_t i = 0; i < data->length; ++i) {
        int value = data->start[i];

        // Apply a more complex mathematical function
        long double result = powl(sinl(powl(value, 1.5)) + cosl(powl(value, 1.5)), 2)
            + log10l(value) + expl(-value);

        // Update the partial sum
        data->partialSum += result;

        // Store the modified value back in memory (casting to int)
        data->start[i] = static_cast<int>(result);
    }

    return 0;
}

// Function that each thread will run to process its chunk of data (for traditional file I/O)
DWORD WINAPI processChunkTraditional(LPVOID param) {
    ThreadDataTraditional* data = static_cast<ThreadDataTraditional*>(param);

    // Allocate a buffer to hold the data
    std::vector<int> buffer(data->length);

    // Seek to the start position in the file
    SetFilePointerEx(data->file, data->startOffset, NULL, FILE_BEGIN);

    // Read data into the buffer
    DWORD bytesToRead = static_cast<DWORD>(data->length * sizeof(int));
    DWORD bytesRead;
    ReadFile(data->file, buffer.data(), bytesToRead, &bytesRead, NULL);

    // Process the data
    for (size_t i = 0; i < data->length; ++i) {
        int value = buffer[i];

        // Apply a more complex mathematical function
        long double result = powl(sinl(powl(value, 1.5)) + cosl(powl(value, 1.5)), 2)
            + log10l(value) + expl(-value);

        // Update the partial sum
        data->partialSum += result;

        // Store the modified value back in the buffer (casting to int)
        buffer[i] = static_cast<int>(result);
    }

    // Seek back to the start position
    SetFilePointerEx(data->file, data->startOffset, NULL, FILE_BEGIN);

    // Write the modified data back to the file
    DWORD bytesToWrite = static_cast<DWORD>(data->length * sizeof(int));
    DWORD bytesWritten;
    WriteFile(data->file, buffer.data(), bytesToWrite, &bytesWritten, NULL);

    // Close the file handle for this thread
    CloseHandle(data->file);

    return 0;
}

// Function to fill a file with random integers
void fillFileWithInts(const char* filename, size_t numInts) {
    // Create or overwrite the file
    HANDLE file = CreateFileA(
        filename,
        GENERIC_WRITE,
        0,
        nullptr,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);

    // Generate random data
    std::vector<int> data(numInts);
    for (size_t i = 0; i < numInts; i++) {
        data[i] = rand() % 1000 + 1; // Random integers from 1 to 1000
    }

    // Write data to the file
    DWORD bytesWritten;
    WriteFile(file, data.data(), static_cast<DWORD>(numInts * sizeof(int)), &bytesWritten, nullptr);

    // Close the file handle
    CloseHandle(file);
}

// Function to calculate the average using memory-mapped files
void mmapAverage(const char* filename) {
    // Open the file for reading and writing
    HANDLE file = CreateFileA(
        filename,
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);

    // Get the size of the file
    LARGE_INTEGER fileSize;
    GetFileSizeEx(file, &fileSize);

    // Create a file mapping object
    HANDLE fileMapping = CreateFileMappingA(
        file,
        nullptr,
        PAGE_READWRITE,
        0,
        0,
        nullptr);

    // Map the entire file into memory
    int* data = static_cast<int*>(MapViewOfFile(
        fileMapping,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0));

    // Calculate the total number of integers in the file
    size_t numInts = fileSize.QuadPart / sizeof(int);
    size_t chunkSize = numInts / NUM_THREADS;

    // Vectors to hold thread handles and data
    std::vector<HANDLE> threads(NUM_THREADS);
    std::vector<ThreadDataMMap> threadData(NUM_THREADS);

    // Create threads to process chunks of the file
    for (size_t i = 0; i < NUM_THREADS; i++) {
        // Calculate the start and end positions for this thread
        size_t start = i * chunkSize;
        size_t end = (i == NUM_THREADS - 1) ? numInts : (start + chunkSize);
        size_t length = end - start;

        // Initialize thread data
        threadData[i] = { data + start, length, 0 };

        // Create the thread
        threads[i] = CreateThread(
            nullptr,
            0,
            processChunkMMap,
            &threadData[i],
            0,
            nullptr);
    }

    // Wait for all threads to complete
    WaitForMultipleObjects(static_cast<DWORD>(NUM_THREADS), threads.data(), TRUE, INFINITE);

    // Calculate the total sum and average
    long double totalSum = 0;
    for (size_t i = 0; i < NUM_THREADS; i++) {
        totalSum += threadData[i].partialSum;
        CloseHandle(threads[i]);
    }

    long double totalAverage = totalSum / numInts;

    std::cout << "Memory-mapped average value: " << totalAverage << std::endl;

    // Unmap the file and close handles
    UnmapViewOfFile(data);
    CloseHandle(fileMapping);
    CloseHandle(file);
}

// Function to calculate the average using traditional file I/O
void traditionalAverage(const char* filename) {
    // Open the file for reading and writing
    HANDLE file = CreateFileA(
        filename,
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);

    // Get the size of the file
    LARGE_INTEGER fileSize;
    GetFileSizeEx(file, &fileSize);

    // Calculate the total number of integers in the file
    size_t numInts = fileSize.QuadPart / sizeof(int);
    size_t chunkSize = numInts / NUM_THREADS;

    // Vectors to hold thread handles and data
    std::vector<HANDLE> threads(NUM_THREADS);
    std::vector<ThreadDataTraditional> threadData(NUM_THREADS);

    // Create threads to process chunks of the file
    for (size_t i = 0; i < NUM_THREADS; i++) {
        // Calculate the start and end positions for this thread
        size_t start = i * chunkSize;
        size_t end = (i == NUM_THREADS - 1) ? numInts : (start + chunkSize);
        size_t length = end - start;

        // Duplicate the file handle for this thread
        HANDLE threadFileHandle;
        DuplicateHandle(
            GetCurrentProcess(),
            file,
            GetCurrentProcess(),
            &threadFileHandle,
            0,
            FALSE,
            DUPLICATE_SAME_ACCESS);

        // Calculate the start offset in bytes
        LARGE_INTEGER startOffset;
        startOffset.QuadPart = start * sizeof(int);

        // Initialize thread data
        threadData[i] = { threadFileHandle, startOffset, length, 0 };

        // Create the thread
        threads[i] = CreateThread(
            nullptr,
            0,
            processChunkTraditional,
            &threadData[i],
            0,
            nullptr);
    }

    // Wait for all threads to complete
    WaitForMultipleObjects(static_cast<DWORD>(NUM_THREADS), threads.data(), TRUE, INFINITE);

    // Calculate the total sum and average
    long double totalSum = 0;
    for (size_t i = 0; i < NUM_THREADS; i++) {
        totalSum += threadData[i].partialSum;
        CloseHandle(threads[i]);
    }

    long double totalAverage = totalSum / numInts;

    std::cout << "Traditional average value: " << totalAverage << std::endl;

    // Close the main file handle
    CloseHandle(file);
}

int main() {
    // Record the start time for random number generation
    time_t startTime = time(0);
    const char* filename = "largefile.dat";

    // Loop over different numbers of threads
    for (NUM_THREADS = 1; NUM_THREADS <= 8; NUM_THREADS++) {
        std::cout << "Number of threads: " << NUM_THREADS << '\n';

        // Seed the random number generator
        srand(static_cast<unsigned int>(startTime));

        // Fill the file with random integers
        fillFileWithInts(filename, NUM_INTS);

        // Measure the time taken by the memory-mapped average calculation
        auto start = std::chrono::high_resolution_clock::now();
        mmapAverage(filename);
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> mmapDuration = end - start;
        std::cout << "Memory-mapped average calculation duration: " << mmapDuration.count() << " seconds\n";

        // Fill the file again to reset data
        srand(static_cast<unsigned int>(startTime));
        fillFileWithInts(filename, NUM_INTS);

        // Measure the time taken by the traditional average calculation
        start = std::chrono::high_resolution_clock::now();
        traditionalAverage(filename);
        end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> traditionalDuration = end - start;
        std::cout << "Traditional average calculation duration: " << traditionalDuration.count() << " seconds\n";

        // Compare the durations
        std::cout << "Speedup: " << traditionalDuration.count() / mmapDuration.count() << "x\n";

        std::cout << '\n';
    }

    return 0;
}
